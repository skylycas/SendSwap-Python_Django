from django import forms


COUNTRY_LIST = [
    ('countries', 'Country'),
    ('canada', 'Canada'),
    ('ghana', 'Ghana'),
    ('nigeria', 'Nigeria'),
]

COUNTRYCURRENY_LIST = [
    ('countries', '--SELECT--'),
    ('canada', 'Canada - CAD'),
    ('ghana', 'Ghana - GHS'),
    ('nigeria', 'Nigeria - NGN'),
]


MONTH_LIST = [
    ('1', 'Jan'),
    ('2', 'Feb'),
    ('3', 'Mar'),
    ('4', 'Apr'),
    ('5', 'May'),
    ('6', 'Jun'),
    ('7', 'Jul'),
    ('8', 'Aug'),
    ('9', 'Sep'),
    ('10', 'Oct'),
    ('11', 'Nov'),
    ('12', 'Dec'),
]
YEAR_LIST = [
    ('2022', '2022'),
    ('2023', '2023'),
    ('2024', '2024'),
    ('2025', '2025'),
    ('2026', '2026'),
    ('2027', '2027'),
    ('2028', '2028'),
    ('2029', '2029'),
    ('2030', '2030'),
    ('2031', '2031'),
    ('2032', '2032'),
    ('2033', '2033'),
]

class singupForm(forms.Form):
    txtfullname = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Full Name", "class": "form-control form-control-xl"}), label="")
    txtnickname = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Nickname", "class": "form-control form-control-xl"}), label="")
    txtemail = forms.EmailField(required=True, widget=forms.widgets.EmailInput(attrs={"placeholder": "Email", "class": "form-control form-control-xl"}), label="")
    txtphone = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Phone", "class": "form-control form-control-xl"}), label="")
    txtusername = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Username", "class": "form-control form-control-xl"}), label="")
    txtpassword = forms.CharField(required=True, widget=forms.widgets.PasswordInput(attrs={"placeholder": "Password", "class": "form-control form-control-xl"}), label="")
    ddlcountry = forms.ChoiceField(required=True, choices=COUNTRY_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")



class loginForm(forms.Form):
    txtusername = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Username", "class": "form-control form-control-xl"}), label="")
    txtpassword = forms.CharField(required=True, widget=forms.widgets.PasswordInput(attrs={"placeholder": "Password", "class": "form-control form-control-xl"}), label="")
    chkkeepsignedin = forms.BooleanField(widget=forms.widgets.CheckboxInput(attrs={"class": "form-control form-check-input me-2"}), label="")


class emailconfirmationForm(forms.Form):
    txtemailcofirmcode = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Enter Confirmation Code", "class": "form-control form-control-xl"}), label="")


class sourceaccountForm(forms.Form):
    txtcardnumber = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Card Number", "class": "form-control form-control-xl"}), label="")    
    ddlmonths = forms.ChoiceField(required=True, choices=MONTH_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    ddlyears = forms.ChoiceField(required=True, choices=YEAR_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    txtcvv = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "CVC", "class": "form-control form-control-xl"}), label="")
    txtstreet = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Street", "class": "form-control form-control-xl"}), label="")
    ddlcountry = forms.ChoiceField(required=True, choices=COUNTRY_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    txtprovince = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Province/State", "class": "form-control form-control-xl"}), label="")
    txtcity = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "City", "class": "form-control form-control-xl"}), label="")



class receiveaccountForm(forms.Form):
    txtcardnumber = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Card Number", "class": "form-control form-control-xl"}), label="")    
    ddlmonths = forms.ChoiceField(required=True, choices=MONTH_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    ddlyears = forms.ChoiceField(required=True, choices=YEAR_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    txtcvv = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "CVC", "class": "form-control form-control-xl"}), label="")
    txtstreet = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Street", "class": "form-control form-control-xl"}), label="")
    ddlcountry = forms.ChoiceField(required=True, choices=COUNTRY_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    txtprovince = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Province/State", "class": "form-control form-control-xl"}), label="")
    txtcity = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "City", "class": "form-control form-control-xl"}), label="")


class swapnowForm(forms.Form):
    ddlhave = forms.ChoiceField(required=True, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")
    ddlneed = forms.ChoiceField(required=True, choices=COUNTRYCURRENY_LIST, widget=forms.widgets.Select(attrs={"class": "form-control form-control-xl form-select"}), label="")


class contactForm(forms.Form):
    txtfullname = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Full Name", "class": "form-control form-control-xl"}), label="")
    txtemail = forms.EmailField(required=True, widget=forms.widgets.EmailInput(attrs={"placeholder": "Email", "class": "form-control form-control-xl"}), label="")
    txtsubject = forms.CharField(required=True, widget=forms.widgets.TextInput(attrs={"placeholder": "Subject", "class": "form-control form-control-xl"}), label="")
    txtmessage = forms.CharField(required=True, widget=forms.widgets.Textarea(attrs={"placeholder": "Message", "class": "form-control form-control-xl"}), label="")