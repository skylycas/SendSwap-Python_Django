import uuid
from django.db import models

# Create your models here.
class tbluser(models.Model):
    dbuuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    dbfullname = models.CharField(max_length=250)
    dbnickname = models.CharField(max_length=50)
    dbemail = models.EmailField(max_length=100)
    dbphone = models.CharField(max_length=50)
    dbusername = models.CharField(max_length=50)
    dbpassword = models.CharField(max_length=50)
    dbcountry = models.CharField(max_length=50)
    dbcode = models.CharField(max_length=10)
    iscomfirm = models.BooleanField(max_length=10, default=False)
    def __str__(self):
        return self.dbemail + "--" + self.dbusername


class tblsourceaccount(models.Model):
    dbuuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    dbemail = models.EmailField(max_length=100)
    dbcardnumber = models.CharField(max_length=250)
    dbmonth = models.CharField(max_length=10)
    dbyear = models.CharField(max_length=10)
    dbstreet = models.CharField(max_length=250)
    dbcountry = models.CharField(max_length=50)
    dbprovince = models.CharField(max_length=50)
    dbcity = models.CharField(max_length=50)
    def __str__(self):
        return self.dbemail + "--" + self.dbcardnumber



class tblreceiveaccount(models.Model):
    dbuuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    dbemail = models.EmailField(max_length=100)
    dbcardnumber = models.CharField(max_length=250)
    dbmonth = models.CharField(max_length=10)
    dbyear = models.CharField(max_length=10)
    dbstreet = models.CharField(max_length=250)
    dbcountry = models.CharField(max_length=50)
    dbprovince = models.CharField(max_length=50)
    dbcity = models.CharField(max_length=50)
    def __str__(self):
        return self.dbemail + "--" + self.dbcardnumber