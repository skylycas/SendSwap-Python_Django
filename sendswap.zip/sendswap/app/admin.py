from django.contrib import admin
from .models import tbluser
from .models import tblsourceaccount
from .models import tblreceiveaccount

# Register your models here.
admin.site.register(tbluser)
admin.site.register(tblsourceaccount)
admin.site.register(tblreceiveaccount)