from ntpath import join
from tabnanny import check
from django.shortcuts import redirect, render
from numpy import var

from .myforms import singupForm
from .myforms import loginForm
from .myforms import emailconfirmationForm
from .myforms import sourceaccountForm
from .myforms import receiveaccountForm
from .myforms import swapnowForm
from .myforms import contactForm





from app.models import tbluser
from app.models import tblsourceaccount
from app.models import tblreceiveaccount

from django.core.mail import send_mail
from django.core import serializers
import json
import random
from django.contrib.sessions.models import Session



from django.http import HttpResponse
# Create your views here.

def index(request):
    return render(request, 'index.html')
     # return HttpResponse("welcome to this")

def login(request):
    if request.method == 'POST':
        postedform = loginForm(request.POST)
        if(postedform.is_valid()):
            varusername = postedform.cleaned_data['txtusername']
            varpassword = postedform.cleaned_data['txtpassword']
            varchkkeepsignedin = postedform.cleaned_data['txtpassword']
            retVal = tbluser.objects.filter(dbusername = varusername, dbpassword = varpassword)
            if retVal.exists():
                retVal = serializers.serialize('json', retVal)
                dataVal = json.loads(retVal)
                request.session['varemail'] = dataVal[0]['fields']['dbemail']
                request.session['varnickname'] = dataVal[0]['fields']['dbnickname']
                # if the email is not confirmed yet, redirect to confirmation page
                if dataVal[0]['fields']['iscomfirm'] != True:
                    request.session['msg'] = ""
                    return redirect('/emailconfirmation')
                else:
                    # check if at least one source account and one receiving account has been setup
                    varemail = request.session['varemail']
                    varsourceaccountcount = tblsourceaccount.objects.filter(dbemail = varemail).count()
                    varreceiveaccountcount = tblreceiveaccount.objects.filter(dbemail = varemail).count()
                    if varsourceaccountcount < 1 or varreceiveaccountcount < 1:
                        return redirect('/setupaccount')
                    else:
                        return redirect('/swapnow')
            else:
                varmsg = "Invalid username or password"
                request.session['msg'] = ""
                form = loginForm()
                return render(request, 'login.html', {'varForm':form, 'varmsg':varmsg})
    else:
        form = loginForm()
        return render(request, 'login.html', {'varForm':form})

def signup(request):
    if request.method == 'POST':
        postedform = singupForm(request.POST)
        if postedform.is_valid():
            varfullname = postedform.cleaned_data['txtfullname']
            varnickname = postedform.cleaned_data['txtnickname']
            varemail = postedform.cleaned_data['txtemail']
            varphone = postedform.cleaned_data['txtphone']
            varusername = postedform.cleaned_data['txtusername']
            varpassword = postedform.cleaned_data['txtpassword']
            varcountry = postedform.cleaned_data['ddlcountry']
            if tbluser.objects.filter(dbemail = varemail):
                varmsg = "email already exists, use another or login"
                form = singupForm()
                return render(request, 'signup.html', {'varForm':form, 'varmsg':varmsg})
            else:
                randomcode = random.randint(100000, 999999)
                dataVal = tbluser(
                    dbfullname = varfullname,
                    dbnickname = varnickname,
                    dbemail = varemail,
                    dbphone = varphone,
                    dbusername = varusername,
                    dbpassword = varpassword,
                    dbcountry = varcountry,
                    dbcode = randomcode
                    )
                dataVal.save()
                request.session['varemail'] = varemail
                request.session['varnickname'] = varnickname

                #Send Confirmation Code to email
                send_mail('SendSwap Confirmation Code', 'Confirmation code is: '+ str(randomcode), 'yudotestmail@gmail.com', [varemail], fail_silently=False)
                # redirect to email confirmatiuon page
                return redirect('/emailconfirmation')
    else:
        form = singupForm()
        return render(request, 'signup.html', {'varForm':form})




def emailconfirmation(request):
    if request.method == 'POST':
        postedform = emailconfirmationForm(request.POST)
        if postedform.is_valid():
            varemailconfirmcode = postedform.cleaned_data['txtemailcofirmcode']
            varemail = request.session['varemail']
            # check if the email and code combination exists, the update the isconfirm field
            if tbluser.objects.filter(dbemail = varemail, dbcode = varemailconfirmcode):
                tbluser.objects.filter(dbemail = varemail).update(iscomfirm = True)
                varmsg = "Your emmail has been confirmed successfully, please logout and login again."
                form = emailconfirmationForm()
                return render(request, 'emailconfirmation.html', {'varForm':form, 'varemail':varemail, 'varmsg': varmsg})
            else:
                varmsg = "Incorrect confirmation code"
                form = emailconfirmationForm()
                return render(request, 'emailconfirmation.html', {'varForm':form, 'varmsg': varmsg})
    else:
        if request.session.has_key('varemail'):
            form = emailconfirmationForm()
            return render(request, 'emailconfirmation.html', {'varForm':form})
        else:
            request.session['msg'] = "You must login first"
            return redirect('/login')


def setupaccount(request):
    email = ""
    # form = setupaccountForm()
    return render(request, 'setupaccount.html', {'varemail':email})




def logout(request):
    Session.objects.all().delete()
    return redirect('/login')




def sourceaccount(request):
    varemail = request.session['varemail']
    if request.method == 'POST':
        postedform = sourceaccountForm(request.POST)
        if postedform.is_valid():            
            varcardnumber = postedform.cleaned_data['txtcardnumber']
            varmonths = postedform.cleaned_data['ddlmonths']
            varyears = postedform.cleaned_data['ddlyears']
            varcvv = postedform.cleaned_data['txtcvv']
            varstreet = postedform.cleaned_data['txtstreet']
            varcountry = postedform.cleaned_data['ddlcountry']
            varprovince = postedform.cleaned_data['txtprovince']
            varcity = postedform.cleaned_data['txtcity']
            if tblsourceaccount.objects.filter(dbemail = varemail, dbcardnumber = varcardnumber).exists():
                varmsg = "This account information already exists"
            elif tblsourceaccount.objects.filter(dbemail = varemail).count() > 2:
                varmsg = "you can only have a maximun of 3 payment source accounts, delete one to add a different payment source account"
            else:
                dataVal = tblsourceaccount(
                    dbemail = varemail,
                    dbcardnumber = varcardnumber,
                    dbmonth = varmonths,
                    dbyear = varyears,
                    dbstreet = varstreet,
                    dbcountry = varcountry,
                    dbprovince = varprovince,
                    dbcity = varcity
                    )
                dataVal.save()
                varmsg = "Account number " + varcardnumber + " added succesfully."
            # get records from database
            retVal = tblsourceaccount.objects.filter(dbemail = varemail)            
            form = sourceaccountForm()
            return render(request, 'sourceaccount.html', {'varForm':form, 'varmsg': varmsg, 'retVal': retVal})
    else:
        # get records from database
        retVal = tblsourceaccount.objects.filter(dbemail = varemail)
        form = sourceaccountForm()
        return render(request, 'sourceaccount.html', {'varForm':form, 'retVal': retVal})



def deletesourceaccount(request, cardnumber):
    varemail = request.session['varemail']

    tblsourceaccount.objects.filter(dbcardnumber = cardnumber).delete()

    retVal = tblsourceaccount.objects.filter(dbemail = varemail)

    varmsg = "Account number " + cardnumber + " deleted succesfully."
    return redirect('/sourceaccount')



def receiveaccount(request):
    varemail = request.session['varemail']
    if request.method == 'POST':
        postedform = receiveaccountForm(request.POST)
        if postedform.is_valid():            
            varcardnumber = postedform.cleaned_data['txtcardnumber']
            varmonths = postedform.cleaned_data['ddlmonths']
            varyears = postedform.cleaned_data['ddlyears']
            varcvv = postedform.cleaned_data['txtcvv']
            varstreet = postedform.cleaned_data['txtstreet']
            varcountry = postedform.cleaned_data['ddlcountry']
            varprovince = postedform.cleaned_data['txtprovince']
            varcity = postedform.cleaned_data['txtcity']
            if tblreceiveaccount.objects.filter(dbemail = varemail, dbcardnumber = varcardnumber).exists():
                varmsg = "This account information already exists"
            elif tblreceiveaccount.objects.filter(dbemail = varemail).count() > 2:
                varmsg = "you can only have a maximun of 3 payment receiving accounts, delete one to add a different payment receiving account"
            else:
                dataVal = tblreceiveaccount(
                    dbemail = varemail,
                    dbcardnumber = varcardnumber,
                    dbmonth = varmonths,
                    dbyear = varyears,
                    dbstreet = varstreet,
                    dbcountry = varcountry,
                    dbprovince = varprovince,
                    dbcity = varcity
                    )
                dataVal.save()
                varmsg = "Account number " + varcardnumber + " added succesfully."
            # get records from database
            retVal = tblreceiveaccount.objects.filter(dbemail = varemail)            
            form = receiveaccountForm()
            return render(request, 'receiveaccount.html', {'varForm':form, 'varmsg': varmsg, 'retVal': retVal})
    else:
        # get records from database
        retVal = tblreceiveaccount.objects.filter(dbemail = varemail)
        form = receiveaccountForm()
        return render(request, 'receiveaccount.html', {'varForm':form, 'retVal': retVal})

def deletereceiveaccount(request, cardnumber):
    varemail = request.session['varemail']

    tblreceiveaccount.objects.filter(dbcardnumber = cardnumber).delete()

    retVal = tblreceiveaccount.objects.filter(dbemail = varemail)

    varmsg = "Account number " + cardnumber + " deleted succesfully."
    return redirect('/receiveaccount')




def swapnow(request):
    form = swapnowForm()
    return render(request, 'swapnow.html', {'varForm':form})


def contact(request):
    varmsg = ""
    if request.method == 'POST':
        postedform = contactForm(request.POST)
        if postedform.is_valid():            
            varfullname = postedform.cleaned_data['txtfullname']
            varemail = postedform.cleaned_data['txtemail']
            varsubject = postedform.cleaned_data['txtsubject']
            varmessage = postedform.cleaned_data['txtmessage']
            send_mail(varsubject, "", varemail, ['yudotestmail@gmail.com'], fail_silently=False, html_message="<h4>Name: </h4>" + varfullname + "<h4>Message: </h4>"+ varmessage)
            # autoreply
            send_mail(varsubject + "--auto reponse", "", 'noreply@sendSwap.com', [varemail], fail_silently=False, html_message="<h4>Thanks " + varfullname +" for contacting us,</h4> will will get back to you shortly.")
            varmsg = "Message sent successfully."
    form = contactForm()
    return render(request, 'contact.html', {'varForm':form, 'varmsg': varmsg})